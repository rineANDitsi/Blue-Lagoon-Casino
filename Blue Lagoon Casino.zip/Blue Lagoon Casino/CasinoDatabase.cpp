#include "casino.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
int SizeOfFile() {
    ifstream fin("CasinoDatabase.txt");
    int size = 0;
    string line;
    while (getline(fin, line)) size++;
    fin.close();
    return size;
}
void CheckingMoney(Clients* client, string login, int size) {
    for (int i = 0; i < size; i++) {
        Clients& w = client[i];
        if (w.login == login) {
            if (w.balance < 100) {
                do
                {
                    system("cls");
                    cout << "\033[31mYou have run out of credits!\033[0m\n"
                        << "---------------------\n"
                        << "Balnse - " << w.balance 
                        << "\nPlease top up your balance or die.\n"
                        << "[1] Dodep 1000\n";
                    string choice;
                    cin >> choice;
                    if (choice == "1") {
                        w.balance = 1000 + w.balance;
                        saveClients(client, size);
                    }
                } while (w.balance < 100);
                break;
            }
        }
    }
}
void EditClientsData(Clients* client, int size, string game, string login, bool result, double bet, double coefficient) {
    for (int i = 0; i < size; i++) {
        Clients& w = client[i];
        if (w.login == login) {
            if (game == "slots") {
                w.slotsPlayed++;
                w.totalBet += bet;
                if (result) {
                    w.balance -= bet;
                    w.balance += bet * coefficient;
                    w.slotWon++;
                    w.totalWin += bet * coefficient;
                }
                else {
                    w.balance -= bet;
                }
            }
            if (game == "simon") {
                w.simonPlayed++;
                if (coefficient > w.simonMaxScore) {
                    w.simonMaxScore = coefficient;
                }
                w.simonTotalScore += coefficient;
                w.balance += (10 * coefficient) - bet;
                if (((10 * coefficient) - bet) > 0) w.totalWin += (10 * coefficient) - bet;
            }
            saveClients(client, size);
        }
    }
}
Clients* TempolaryDatabase(int& size) {
    size = SizeOfFile();
    ifstream fin("CasinoDatabase.txt");
    fin.clear();
    fin.seekg(0, ios::beg);
    if (size == 0) {
        Clients* clients1 = new Clients[1];
        clients1[0].id = 1;
        clients1[0].name = "Admin";
        clients1[0].age = 0;
        clients1[0].balance = 0;
        clients1[0].totalGamesPlayed = 0;
        clients1[0].blackjackPlayed = 0;
        clients1[0].blackjackWon = 0;
        clients1[0].slotsPlayed = 0;
        clients1[0].slotWon = 0;
        clients1[0].simonPlayed = 0;
        clients1[0].simonTotalScore = 0;
        clients1[0].simonMaxScore = 0;
        clients1[0].totalBet = 0;
        clients1[0].totalWin = 0;
        clients1[0].login = "Admin";
        clients1[0].password = "12";
        size = 1;
        saveClients(clients1, size);
        return clients1;
    }
    Clients* clients = new Clients[size];
    for (int i = 0; i < size; i++) {
        fin >> clients[i].id;
        fin >> clients[i].name;
        fin >> clients[i].age;
        fin >> clients[i].balance;
        fin >> clients[i].totalGamesPlayed;
        fin >> clients[i].blackjackPlayed;
        fin >> clients[i].blackjackWon;
        fin >> clients[i].slotsPlayed;
        fin >> clients[i].slotWon;
        fin >> clients[i].simonPlayed;
        fin >> clients[i].simonTotalScore;
        fin >> clients[i].simonMaxScore;
        fin >> clients[i].totalBet;
        fin >> clients[i].totalWin;
        fin >> clients[i].login;
        fin >> clients[i].password;
    }
    fin.close();
    return clients;
}

void saveClients(Clients* clients, int size) {
    ofstream fout("CasinoDatabase.txt");
    for (int i = 0; i < size; i++) {
        fout << clients[i].id << " "
            << clients[i].name << " "
            << clients[i].age << " "
            << clients[i].balance << " "
            << clients[i].totalGamesPlayed << " "
            << clients[i].blackjackPlayed << " "
            << clients[i].blackjackWon << " "
            << clients[i].slotsPlayed << " "
            << clients[i].slotWon << " "
            << clients[i].simonPlayed << " "
            << clients[i].simonTotalScore << " "
            << clients[i].simonMaxScore << " "
            << clients[i].totalBet << " "
            << clients[i].totalWin << " "
            << clients[i].login << " "
            << clients[i].password << endl;
    }
    fout.close();
}